# API_TOKEN
API_TOKEN ='5750165762:AAHXTubTqTwAVsfruQNpzzInlPQuVUr7f1s'

#Admin ID
admin_id = 888881913

#Database connection settings
dbHost = 'sql.freedb.tech'
dbUser= 'freedb_KomarovKrasyuk'
dbPassword = 'k3Nz6x&7&#JejZZ'
dbName = 'freedb_DatabaseKomarovKrasyuk'